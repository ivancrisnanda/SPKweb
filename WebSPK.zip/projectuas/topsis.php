<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SPK - IVAN CRISNANDA</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<?php
        // Bobot Kriteria
        $bc1 = 30;
        $bc2 = 25;
        $bc3 = 20;
        $bc4 = 25;
        // Kriteria A1
        $a1c1 = 3;
        $a2c1 = 4;
        $a3c1 = 5;
        // Kriteria A2
        $a1c2 = 5;
        $a2c2 = 3;
        $a3c2 = 4;
        // Kriteria A3
        $a1c3 = 3;
        $a2c3 = 2;
        $a3c3 = 5;
        // Kriteria A1
        $a1c4 = 1;
        $a2c4 = 3;
        $a3c4 = 1;
        ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SPK </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="saw.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>SAW</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="wp.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>WP</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="ahp.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>AHP</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="moora.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>MOORA</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="electre.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>ELECTRE</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="topsis.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>TOPSIS</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="gdss.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>GDSS</span></a>
      </li>

  

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
 

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
    

            <!-- Nav Item - User Information -->
            <li class="nav-item">
              <a class="nav-link"  id="userDropdown" role="button"   aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ivan Crisnanda</span> 
              </a> 
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">TOPSIS</h1> 
          </div>

          <!-- Content Row -->
                        <div class="row">


                         <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Skor Ternormalisasi</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>A1</th>
                                                <th>A2</th>
                                                <th>A3</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>C1</th>
                                                <th><?php echo $a1c1?></th>
                                                <th><?php echo $a2c1?></th>
                                                <th><?php echo $a3c1?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C2</th>
                                                <th><?php echo $a1c2?></th>
                                                <th><?php echo $a2c2?></th>
                                                <th><?php echo $a3c2?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C3</th>
                                                <th><?php echo $a1c3?></th>
                                                <th><?php echo $a2c3?></th>
                                                <th><?php echo $a3c3?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C4</th>
                                                <th><?php echo $a1c4?></th>
                                                <th><?php echo $a2c4?></th>
                                                <th><?php echo $a3c4?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
<?php
    // Mengitung skor ternormalisasi
    // C1
    $r11 = $a1c1/sqrt(pow($a1c1,2)+pow($a2c1,2)+pow($a3c1,2));
    $r21 = $a2c1/sqrt(pow($a1c1,2)+pow($a2c1,2)+pow($a3c1,2));
    $r31 = $a3c1/sqrt(pow($a1c1,2)+pow($a2c1,2)+pow($a3c1,2));
    // C2
    $r12 = $a1c2/sqrt(pow($a1c2,2)+pow($a2c2,2)+pow($a3c2,2));
    $r22 = $a2c2/sqrt(pow($a1c2,2)+pow($a2c2,2)+pow($a3c2,2));
    $r32 = $a3c2/sqrt(pow($a1c2,2)+pow($a2c2,2)+pow($a3c2,2));
    // C3
    $r13 = $a1c3/sqrt(pow($a1c3,2)+pow($a2c3,2)+pow($a3c3,2));
    $r23 = $a2c3/sqrt(pow($a1c3,2)+pow($a2c3,2)+pow($a3c3,2));
    $r33 = $a3c3/sqrt(pow($a1c3,2)+pow($a2c3,2)+pow($a3c3,2));
    // C4
    $r14 = $a1c4/sqrt(pow($a1c4,2)+pow($a2c4,2)+pow($a3c4,2));
    $r24 = $a2c4/sqrt(pow($a1c4,2)+pow($a2c4,2)+pow($a3c4,2));
    $r34 = $a3c4/sqrt(pow($a1c4,2)+pow($a2c4,2)+pow($a3c4,2));
    ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>A1</th>
                                                <th>A2</th>
                                                <th>A3</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>C1</th>
                                                <th><?php echo $r11?></th>
                                                <th><?php echo $r21?></th>
                                                <th><?php echo $r31?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C2</th>
                                                <th><?php echo $r12?></th>
                                                <th><?php echo $r22?></th>
                                                <th><?php echo $r32?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C3</th>
                                                <th><?php echo $r13?></th>
                                                <th><?php echo $r23?></th>
                                                <th><?php echo $r33?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C4</th>
                                                <th><?php echo $r14?></th>
                                                <th><?php echo $r24?></th>
                                                <th><?php echo $r34?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
<div>
<?php
    // Mengitung skor ternormalisasi terbobot
    // C1
    $y11 = $r11*$bc1;
    $y21 = $r21*$bc1;
    $y31 = $r31*$bc1;
    // C2
    $y12 = $r12*$bc2;
    $y22 = $r22*$bc2;
    $y32 = $r32*$bc2;
    // C3
    $y13 = $r13*$bc3;
    $y23 = $r23*$bc3;
    $y33 = $r33*$bc3;
    // C4
    $y14 = $r14*$bc4;
    $y24 = $r24*$bc4;
    $y34 = $r34*$bc4;
    ?>                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Skor Normalisasi Terbobot</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>A1</th>
                                                <th>A2</th>
                                                <th>A3</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>C1</th>
                                                <th><?php echo $y11?></th>
                                                <th><?php echo $y21?></th>
                                                <th><?php echo $y31?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C2</th>
                                                <th><?php echo $y12?></th>
                                                <th><?php echo $y22?></th>
                                                <th><?php echo $y32?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C3</th>
                                                <th><?php echo $y13?></th>
                                                <th><?php echo $y23?></th>
                                                <th><?php echo $y33?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>C4</th>
                                                <th><?php echo $y14?></th>
                                                <th><?php echo $y24?></th>
                                                <th><?php echo $y34?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
 <div>                       
  <?php
    // Mengitung solusi ideal positif
    // C1
    $ap1 = max($y11,$y21,$y31);
    // C2
    $ap2 = max($y12,$y22,$y32);
    // C3
    $ap3 = max($y13,$y23,$y33);
    // C4
    $ap4 = min($y14,$y24,$y34);
    ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Solusi Ideal Positif</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>C1</th>
                                                <th>C2</th>
                                                <th>C3</th>
                                                <th>C4</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>A+</th>
                                                <th><?php echo $ap1?></th>
                                                <th><?php echo $ap2?></th>
                                                <th><?php echo $ap3?></th>
                                                <th><?php echo $ap4?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
 <div>                       
   <?php
    // Mengitung solusi ideal negatif
    // C1
    $an1 = min($y11,$y21,$y31);
    // C2
    $an2 = min($y12,$y22,$y32);
    // C3
    $an3 = min($y13,$y23,$y33);
    // C4
    $an4 = max($y14,$y24,$y34);
    ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Solusi Ideal Negatif</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>C1</th>
                                                <th>C2</th>
                                                <th>C3</th>
                                                <th>C4</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>A-</th>
                                                <th><?php echo $an1?></th>
                                                <th><?php echo $an2?></th>
                                                <th><?php echo $an3?></th>
                                                <th><?php echo $an4?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
<div>                       
   <?php
    // Mengitung jarak solusi ideal positif
    // C1
    $dp1 = sqrt(pow(($ap1-$y11),2)+pow(($ap2-$y12),2)+pow(($ap3-$y13),2)+pow(($ap4-$y14),2));
    // C2
    $dp2 = sqrt(pow(($ap1-$y21),2)+pow(($ap2-$y22),2)+pow(($ap3-$y23),2)+pow(($ap4-$y24),2));
    // C3
    $dp3 = sqrt(pow(($ap1-$y31),2)+pow(($ap2-$y32),2)+pow(($ap3-$y33),2)+pow(($ap4-$y34),2));
    ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Jarak Solusi Ideal Positif</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>D1+</th>
                                                <th>D2+</th>
                                                <th>D3+</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>Hasil</th>
                                                <th><?php echo $dp1?></th>
                                                <th><?php echo $dp2?></th>
                                                <th><?php echo $dp3?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
<div>                       
   <?php
    // Mengitung jarak solusi ideal negatif
    // C1
    $dn1 = sqrt(pow(($y11-$an1),2)+pow(($y12-$an2),2)+pow(($y13-$an3),2)+pow(($y14-$an4),2));
    // C2
    $dn2 = sqrt(pow(($y21-$an1),2)+pow(($y22-$an2),2)+pow(($y23-$an3),2)+pow(($y24-$an4),2));
    // C3
    $dn3 = sqrt(pow(($y31-$an1),2)+pow(($y32-$an2),2)+pow(($y33-$an3),2)+pow(($y34-$an4),2));
    ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Jarak Solusi Ideal Negatif</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>D1-</th>
                                                <th>D2-</th>
                                                <th>D3-</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>Hasil</th>
                                                <th><?php echo $dn1?></th>
                                                <th><?php echo $dn2?></th>
                                                <th><?php echo $dn3?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
<div>
    <?php
    // Mengitung skor akhir setiap alternatif
    // C1
    $v1 = $dn1/($dn1+$dp1);
    // C2
    $v2 = $dn2/($dn2+$dp2);
    // C3
    $v3 = $dn3/($dn3+$dp3);
    ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Skor Akhir Keputusan</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th></th>
                                                <th>V1</th>
                                                <th>V2</th>
                                                <th>V3</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>Hasil</th>
                                                <th><?php echo $v1?></th>
                                                <th><?php echo $v2?></th>
                                                <th><?php echo $v3?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div> 
 <?php
        if ($v1 > $v2 && $v1 > $v3) {
            echo ("<h4><b>Pilihan yang terpilih adalah Alternatif 1 yaitu Sepatu 1</b></h4>");
        }elseif ($v2 > $v3 && $v2 > $v1) {
            echo ("<h4><b>Pilihan yang terpilih adalah Alternatif 2 yaitu Sepatu 2</b></h4>");
        } else {
            echo ("<h4><b>Pilihan yang terpilih adalah Alternatif 3</b></h4>");
        }

        ?>                                                      
            </div>
        </div>
    </div>

  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
   

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
