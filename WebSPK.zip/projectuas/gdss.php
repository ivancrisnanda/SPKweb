<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SPK - IVAN CRISNANDA</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<?php
        // Bobot Kriteria
        $bc1 = 30;
        $bc2 = 25;
        $bc3 = 20;
        $bc4 = 25;
        // Kriteria A1
        $a1c1 = 3;
        $a2c1 = 4;
        $a3c1 = 5;
        // Kriteria A2
        $a1c2 = 5;
        $a2c2 = 3;
        $a3c2 = 4;
        // Kriteria A3
        $a1c3 = 3;
        $a2c3 = 2;
        $a3c3 = 5;
        // Kriteria A1
        $a1c4 = 1;
        $a2c4 = 3;
        $a3c4 = 1;
        ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SPK </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="saw.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>SAW</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="wp.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>WP</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="ahp.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>AHP</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="moora.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>MOORA</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="electre.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>ELECTRE</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="topsis.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>TOPSIS</span></a>
      </li>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="gdss.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>GDSS</span></a>
      </li>

  

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
 

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
    

            <!-- Nav Item - User Information -->
            <li class="nav-item">
              <a class="nav-link"  id="userDropdown" role="button"   aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ivan Crisnanda</span> 
              </a> 
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">GDSS</h1> 
          </div>

          <!-- Content Row -->
                        <div class="row">


                    <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Penyelesaian Dengan Moora</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th>Juri 1</th>
                                                <th>Nilai Yi</th>
                                                <th>Ranking</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>A1</th>
                                                <th><?php echo $a1j1 = 0.228?></th>
                                                <th>2</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A2</th>
                                                <th><?php echo $a2j1 = 0.212?></th>
                                                <th>4</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A3</th>
                                                <th><?php echo $a3j1 = 0.216?></th>
                                                <th>3</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A4</th>
                                                <th><?php echo $a4j1 = 0.184?></th>
                                                <th>5</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A5</th>
                                                <th><?php echo $a5j1 = 0.249?></th>
                                                <th>1</th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th>Juri 2</th>
                                                <th>Nilai Yi</th>
                                                <th>Ranking</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>A1</th>
                                                <th><?php echo $a1j2 = 0.220?></th>
                                                <th>3</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A2</th>
                                                <th><?php echo $a2j2 = 0.252?></th>
                                                <th>1</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A3</th>
                                                <th><?php echo $a3j2 = 0.195?></th>
                                                <th>5</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A4</th>
                                                <th><?php echo $a4j2 = 0.221?></th>
                                                <th>2</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A5</th>
                                                <th><?php echo $a5j2 = 0.206?></th>
                                                <th>4</th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th>Juri 3</th>
                                                <th>Nilai Yi</th>
                                                <th>Ranking</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>A1</th>
                                                <th><?php echo $a1j3 = 0.230?></th>
                                                <th>2</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A2</th>
                                                <th><?php echo $a2j3 = 0.245?></th>
                                                <th>1</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A3</th>
                                                <th><?php echo $a3j3 = 0.209?></th>
                                                <th>3</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A4</th>
                                                <th><?php echo $a4j3 = 0.198?></th>
                                                <th>5</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A5</th>
                                                <th><?php echo $a5j3 = 0.205?></th>
                                                <th>4</th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

<div>
                       
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Bobot Borda</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th>Ranking 1</th>
                                                <th>Ranking 2</th>
                                                <th>Ranking 3</th>
                                                <th>Ranking 4</th>
                                                <th>Ranking 5</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th><?php echo $bb1 = 5?></th>
                                                <th><?php echo $bb2 = 4?></th>
                                                <th><?php echo $bb3 = 3?></th>
                                                <th><?php echo $bb4 = 2?></th>
                                                <th><?php echo $bb5 = 1?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
 <div>                       

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Menghitung Borda</h6> 
                                </div> 
                              </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th>Ranking</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th>A1</th>
                                                <th><?php echo $a1rb1 = 0*$bb1?></th>
                                                <th><?php echo $a1rb2 = ($a1j1+$a1j3)*$bb2?></th>
                                                <th><?php echo $a1rb3 = $a1j2*$bb3?></th>
                                                <th><?php echo $a1rb4 = 0*$bb4?></th>
                                                <th><?php echo $a1rb5 = 0*$bb5?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A2</th>
                                                <th><?php echo $a2rb1 = ($a2j2+$a2j3)*$bb1?></th>
                                                <th><?php echo $a2rb2 = 0*$bb2?></th>
                                                <th><?php echo $a2rb3 = 0*$bb3?></th>
                                                <th><?php echo $a2rb4 = $a2j1*$bb4?></th>
                                                <th><?php echo $a2rb5 = 0*$bb5?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A3</th>
                                                <th><?php echo $a3rb1 = 0*$bb1?></th>
                                                <th><?php echo $a3rb2 = 0*$bb2?></th>
                                                <th><?php echo $a3rb3 = ($a3j1+$a3j3)*$bb3?></th>
                                                <th><?php echo $a3rb4 = 0*$bb4?></th>
                                                <th><?php echo $a3rb5 = $a3j2*$bb5?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A4</th>
                                                <th><?php echo $a4rb1 = 0*$bb1?></th>
                                                <th><?php echo $a4rb2 = $a4j2*$bb2?></th>
                                                <th><?php echo $a4rb3 = 0*$bb3?></th>
                                                <th><?php echo $a4rb4 = 0*$bb4?></th>
                                                <th><?php echo $a4rb5 = ($a4j1+$a4j3)*$bb5?></th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th>A5</th>
                                                <th><?php echo $a5rb1 = $a5j1*$bb1?></th>
                                                <th><?php echo $a5rb2 = 0*$bb2?></th>
                                                <th><?php echo $a5rb3 = 0*$bb3?></th>
                                                <th><?php echo $a5rb4 = ($a5j2+$a5j3)*$bb4?></th>
                                                <th><?php echo $a5rb5 = 0*$bb5?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
 <div>                       
<?php
        $pb1 = $a1rb1+$a2rb1+$a3rb1+$a4rb1+$a5rb1;
        $pb2 = $a1rb2+$a2rb2+$a3rb2+$a4rb2+$a5rb2;
        $pb3 = $a1rb3+$a2rb3+$a3rb3+$a4rb3+$a5rb3;
        $pb4 = $a1rb4+$a2rb4+$a3rb4+$a4rb4+$a5rb4;
        $pb5 = $a1rb5+$a2rb5+$a3rb5+$a4rb5+$a5rb5;
        $tpb = $pb1+$pb2+$pb3+$pb4+$pb5;
        ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr style="text-align: center;">
                                                <th>Poin Borda</th>
                                                <th>Nilai Borda</th>
                                                <th>Ranking</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr style="text-align: center;">
                                                <th><?php echo $pb1?></th>
                                                <th><?php echo number_format($pb1/$tpb,3,",",".")?></th>
                                                <th>2</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th><?php echo $pb2?></th>
                                                <th><?php echo number_format($pb2/$tpb,3,",",".")?></th>
                                                <th>1</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th><?php echo $pb3?></th>
                                                <th><?php echo number_format($pb3/$tpb,3,",",".")?></th>
                                                <th>4</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th><?php echo $pb4?></th>
                                                <th><?php echo number_format($pb4/$tpb,3,",",".")?></th>
                                                <th>5</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th><?php echo $pb5?></th>
                                                <th><?php echo number_format($pb5/$tpb,3,",",".")?></th>
                                                <th>3</th>
                                            </tr>
                                            <tr style="text-align: center;">
                                                <th><?php echo $tpb?></th>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div> 
                              <h4 class="m-0 font-weight-bold text-primary">Pilihan yang terpilih adalah Apartemen 2</h4>  
                            </div>
                        </div>
                    </div>                                                      
            </div>
        </div>
    </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
   

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
